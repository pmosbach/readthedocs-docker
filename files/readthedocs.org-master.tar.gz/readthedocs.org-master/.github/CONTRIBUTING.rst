Please review our contributing documentation located at http://docs.readthedocs.org/en/latest/contribute.html
